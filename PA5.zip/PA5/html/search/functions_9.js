var searchData=
[
  ['triangle_75',['Triangle',['../classTriangle.html#a3e589817b5a84e85cffce6bd128edf10',1,'Triangle']]]
];
