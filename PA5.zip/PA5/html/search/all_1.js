var searchData=
[
  ['equalswithintolerance_2',['EqualsWithinTolerance',['../float__compare_8hpp.html#a5964f2573c9f5aa81c50826dfac3cb81',1,'EqualsWithinTolerance(const double &amp;num_1, const double &amp;num_2):&#160;float_compare.hpp'],['../float__compare_8hpp.html#ab35942669ec9351e073add9851717fd6',1,'EqualsWithinTolerance(const Eigen::Matrix2d &amp;mat_1, const Eigen::Matrix2d &amp;mat_2):&#160;float_compare.hpp'],['../float__compare_8hpp.html#afb37917bc1ddaac2ce1c27e40f185736',1,'EqualsWithinTolerance(const Eigen::Vector2d &amp;vec_1, const Eigen::Vector2d &amp;vec_2):&#160;float_compare.hpp'],['../float__compare_8hpp.html#ab67553848ff5b7607944a537f19b00b6',1,'EqualsWithinTolerance(const Eigen::Vector3d &amp;vec_1, const Eigen::Vector3d &amp;vec_2):&#160;float_compare.hpp']]]
];
