var searchData=
[
  ['triangle_42',['Triangle',['../classTriangle.html',1,'']]]
];
